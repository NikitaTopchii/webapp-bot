create
    definer = rdsadmin@localhost procedure rds_stop_upgrade_prechecks()
BEGIN
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE v_engine_version VARCHAR(50);
    DECLARE most_recent_action VARCHAR(20);
    DECLARE most_recent_status VARCHAR(50);
    DECLARE sql_logging BOOLEAN;
    SELECT @@sql_log_bin INTO sql_logging;

    BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
                BEGIN
                    SET @@sql_log_bin=sql_logging;
                    RESIGNAL;
                END;
        SET @@sql_log_bin=OFF;

        SELECT user() INTO v_called_by_user;
        SELECT version() INTO v_engine_version;
        
        INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'stop prechecks', v_engine_version);
        COMMIT;
        SELECT action INTO most_recent_action FROM mysql.rds_upgrade_prechecks ORDER BY start_timestamp DESC LIMIT 1;
        SELECT status INTO most_recent_status FROM mysql.rds_upgrade_prechecks ORDER BY start_timestamp DESC LIMIT 1;

        IF most_recent_action = 'engine upgrade' AND most_recent_status IN ('pending','in progress') THEN
           SIGNAL SQLSTATE '45002' SET MESSAGE_TEXT = 'Cannot call procedure while engine upgrade in progress.';
        ELSEIF most_recent_action = 'stop' OR most_recent_status IN ('stopped','unable to be completed','prechecks failed','prechecks passed') THEN
           SIGNAL SQLSTATE '45002' SET MESSAGE_TEXT = 'Cannot call procedure, upgrade prechecks not running.';
        ELSE
           INSERT INTO mysql.rds_upgrade_prechecks(action,status) VALUES ('stop','pending');
           UPDATE mysql.rds_upgrade_prechecks SET status = 'stopping' WHERE status IN ('pending', 'in progress');
           
           INSERT INTO mysql.rds_history(called_by_user,action,mysql_version) VALUES (v_called_by_user,'stop prechecks:ok',v_engine_version);
           COMMIT;
           SELECT 'Stopping upgrade prechecks.' as `Success`;
        END IF;

        SET @@sql_log_bin=sql_logging;
    END;

END;

